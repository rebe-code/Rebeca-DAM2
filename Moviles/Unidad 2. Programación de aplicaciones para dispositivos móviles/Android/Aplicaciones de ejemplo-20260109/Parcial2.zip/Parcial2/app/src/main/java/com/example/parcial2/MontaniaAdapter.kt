package com.example.parcial2

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class MontaniaAdapter(): BaseAdapter() {
    private var context: Context? = null
    private var datos: ArrayList<Montania> = ArrayList<Montania>()

    constructor(context: Context, datos: ArrayList<Montania>) : this() {
        this.context = context
        this.datos = datos
    }

    override fun getCount(): Int {
        return datos.size
    }

    override fun getItem(position: Int): Any {
        return datos[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {
        val vista = view?.let {
            view
        } ?:run{
            LayoutInflater.from(context).inflate(R.layout.item_montana, parent, false)
        }

        val icono = vista.findViewById<ImageView>(R.id.icono)
        val texto_mountain = vista.findViewById<TextView>(R.id.nombreYAltura)
        val concejo_mountain = vista.findViewById<TextView>(R.id.concejo)

        val datosItem = getItem(position) as Montania
        val nombre = datosItem.nombre
        val idImagen = context!!.resources.getIdentifier(nombre.lowercase(), "drawable", context!!.packageName)
        if (idImagen != 0){
            icono.setImageResource(idImagen)
        } else {
            icono.setImageResource(android.R.drawable.ic_menu_mapmode)
        }
        var texto = nombre
        if (datosItem.altura != 0){
            texto = context!!.getString(R.string.texto_montana, nombre, datosItem.altura.toString())
        }
        texto_mountain.text = texto
        concejo_mountain.text = datosItem.concejo

        return vista;
    }
}