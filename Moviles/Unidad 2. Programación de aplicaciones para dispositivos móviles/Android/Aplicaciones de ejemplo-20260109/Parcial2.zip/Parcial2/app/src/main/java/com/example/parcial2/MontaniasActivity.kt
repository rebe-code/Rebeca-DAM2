package com.example.parcial2

import android.content.ContentValues
import android.database.Cursor
import android.os.Bundle
import android.util.Log
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.parcial2.bbdd.BBDD_Helper
import java.util.Locale

class MontaniasActivity : AppCompatActivity() {
    val conexion = BBDD_Helper(this,"parcial2", null, 1)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.montanias)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.montanias)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val parametros = intent.extras
        val usuario = parametros?.getString("usuario");
        val montanas = this.obtenerMontanasUsuario(usuario)
        this.actualizarContadorMontanias(usuario, montanas)

        this.habilitarNuevaMontania(usuario)

        findViewById<Button>(R.id.btnNuevo).setOnClickListener {
            this.mostrarDialogoMontania(usuario, null)
        }

        val datos = this.obtenerListaMontanias(montanas)
        val lista = findViewById<ListView>(R.id.list_view_montain)
        val adaptador = MontaniaAdapter(this, datos)
        lista.adapter = adaptador
        lista.setOnItemClickListener { _, view, position, _ ->
            val popup = PopupMenu(this, view)
            val inflater: MenuInflater = popup.menuInflater
            var opcionesMenu = R.menu.menu_item_montana
            if (usuario == "admin"){
                opcionesMenu = R.menu.menu_item_montana_admin
            }
            inflater.inflate(opcionesMenu, popup.menu)
            popup.setOnMenuItemClickListener(
                fun (menuItem: MenuItem): Boolean {
                    val montania = adaptador.getItem(position) as Montania
                    return when (menuItem.itemId) {
                        R.id.modificar -> {
                            this.mostrarDialogoMontania(usuario, montania)
                            true
                        }
                        R.id.eliminar -> {
                            this.eliminarMontania(usuario, montania)
                            true
                        }
                        else -> false
                    }
                }
            )
            popup.show()
        }
    }

    private fun obtenerMontanasUsuario(usuario: String?): Cursor {
        val bd = this.conexion.readableDatabase
        Log.d("MontaniasActivity - obtenerMontanasUsuario", "Obtenemos las montañas del usuario $usuario")
        var sql = "SELECT * FROM montania WHERE usuario = '$usuario'"
        if (usuario == "admin"){
            sql = "SELECT * FROM montania"
        }
        return bd.rawQuery(sql, null)
    }

    private fun actualizarContadorMontanias(usuario: String?, montanas: Cursor){
        val numMontanas = montanas.count
        Log.d("MontaniasActivity - actualizarContadorMontanias", "Número de montañas del usuario $usuario = $numMontanas")
        findViewById<TextView>(R.id.numero_montanas).text = getString(R.string.numero_montanas, numMontanas.toString())
    }

    private fun habilitarNuevaMontania(usuario: String?){
        if (usuario == "admin"){
            findViewById<Button>(R.id.btnNuevo).visibility = View.VISIBLE
        } else {
            findViewById<Button>(R.id.btnNuevo).visibility = View.GONE
        }
    }

    private fun mostrarDialogoMontania(usuario: String?, montania: Montania?) {
        val dialogo = layoutInflater.inflate(R.layout.detalle_montana, null)
        val etNombreMontana = dialogo.findViewById<EditText>(R.id.etNombreMontana)
        val sUsuarioMontana = dialogo.findViewById<Spinner>(R.id.sUsuarioMontana)
        val etAlturaMontana = dialogo.findViewById<EditText>(R.id.etAlturaMontana)
        val etConcejoMontana = dialogo.findViewById<EditText>(R.id.etConcejoMontana)

        val tituloDialogo: Int
        if (montania != null) {
            Log.d(
                "MontaniaActivity - mostrarDialogoMontania",
                "montania != null -> opción 'Modificar montaña'"
            )
            tituloDialogo = R.string.modificar_montana
            etNombreMontana.setText(montania.nombre)
            etNombreMontana.isEnabled = false
            sUsuarioMontana.setSelection(this.obtenerPosicionUsuario(sUsuarioMontana, montania.usuario))
            sUsuarioMontana.isEnabled = false
            etAlturaMontana.setText(String.format(Locale.getDefault(),"%d", montania.altura))
            etConcejoMontana.setText(montania.concejo)
        } else {
            Log.d(
                "MontaniaActivity - mostrarDialogoMontania",
                "montania != null -> opción 'Añadir montaña'"
            )
            tituloDialogo = R.string.nueva_montana
            etNombreMontana.isEnabled = true
            sUsuarioMontana.isEnabled = true
        }

        val alertDialog = AlertDialog.Builder(this)
            .setTitle(tituloDialogo)
            .setView(dialogo)
            .setPositiveButton(R.string.guardar) { _, _ ->
                val nombreMontania = etNombreMontana.text.toString()
                val usuarioMontania = sUsuarioMontana.selectedItem.toString()

                if (nombreMontania.isNotEmpty() && usuarioMontania.isNotEmpty()) {
                    var altura = 0
                    val alturaMontania = etAlturaMontana.text.toString()
                    if (alturaMontania != getString(R.string.vacio)) {
                        altura = alturaMontania.toInt()
                    }
                    var concejo = etConcejoMontana.text.toString()
                    if (montania == null) {
                        this.addMontania(nombreMontania, usuarioMontania, altura, concejo)
                    } else {
                        this.editMontania(nombreMontania, usuarioMontania, altura, concejo)
                    }
                } else {
                    Toast.makeText(this, R.string.error_datos_obligatorios, Toast.LENGTH_SHORT)
                        .show()
                }
                this.actualizarMontanias(usuario)
            }
            .setNegativeButton(R.string.cancelar, null)

        if (usuario == "admin" || montania != null) {
            alertDialog.show()
        }
    }

    private fun obtenerPosicionUsuario(spinner: Spinner, usuario: String): Int{
        var posicion = -1
        for (i in 0..<spinner.count) {
            if (spinner.getItemAtPosition(i).equals(usuario)) {
                posicion = i
                break;
            }
        }
        return posicion
    }

    private fun addMontania(nombre: String, usuario: String, altura: Int, concejo: String){
        val bd = conexion.writableDatabase
        val registro = ContentValues()
        registro.put("nombre", nombre)
        registro.put("usuario", usuario)
        registro.put("altura", altura)
        registro.put("concejo", concejo)
        bd.insert("montania", null, registro)
        Log.d("MontaniasActivity - addMontania", "Se inserta el registro con los datos: $nombre - $usuario - $altura - $concejo")
    }

    private fun editMontania(nombre: String, usuario: String, altura: Int, concejo: String){
        val bd = conexion.writableDatabase
        val valores = ContentValues().apply {
            put("altura", altura)
            put("concejo", concejo)
        }
        val seleccion = "nombre like ? and usuario like ?"
        val seleccionArgs = arrayOf(nombre, usuario)
        val filasAfectadas = bd.update("montania", valores, seleccion, seleccionArgs)
        if (filasAfectadas != 1){
            Log.e("MontaniasActivity - editMontania", "Error al actualizar la montaña con clave: $nombre - $usuario")
        } else {
            Log.d("MontaniasActivity - editMontania", "Actualizada correctamente la montaña con clave: $nombre - $usuario")
        }
    }

    private fun actualizarMontanias(usuario: String?){
        var listado = findViewById<ListView>(R.id.list_view_montain)
        val montanias = this.obtenerMontanasUsuario(usuario)
        val datos = obtenerListaMontanias(montanias)
        val adaptador = MontaniaAdapter(this, datos)
        listado.adapter = adaptador
        this.actualizarContadorMontanias(usuario, montanias)
    }

    private fun obtenerListaMontanias(montanias: Cursor): ArrayList<Montania>{
        val datos = arrayListOf<Montania>()
        while (montanias.moveToNext()){
            val nombre = montanias.getString(montanias.getColumnIndexOrThrow("nombre"))
            val usuario = montanias.getString(montanias.getColumnIndexOrThrow("usuario"))
            val altura = montanias.getInt(montanias.getColumnIndexOrThrow("altura"))
            var concejo = montanias.getString(montanias.getColumnIndexOrThrow("concejo"))
            if (concejo == null){
                concejo = getString(R.string.vacio)
            }
            datos.add(Montania(nombre, usuario, altura, concejo))
        }
        return datos;
    }

    private fun eliminarMontania(usuario: String?, montania: Montania){
        if (usuario == "admin"){
            AlertDialog.Builder(this)
                .setTitle(R.string.eliminar_montana)
                .setMessage(getString(R.string.borrar_montana, montania.nombre))
                .setPositiveButton("Sí") { _, _ ->
                    this.borrarMontana(montania)
                    this.actualizarMontanias(usuario)
                }
                .setNegativeButton("No", null)
                .show()
        }
    }

    private fun borrarMontana(montania: Montania) {
        val bd = conexion.writableDatabase
        val seleccion = "nombre like ? and usuario like ?"
        val nombre = montania.nombre
        val usuario = montania.usuario
        val seleccionArgs = arrayOf(nombre, usuario)
        val filasEliminadas = bd.delete("montania", seleccion, seleccionArgs)
        if (filasEliminadas != 1){
            Log.e("MontaniasActivity - borrarMontana", "Error al eliminar la montaña con clave: $nombre - $usuario")
        } else {
            Log.d("MontaniasActivity - borrarMontana", "Eliminada correctamente la montaña con clave: $nombre - $usuario")
        }
    }

    override fun onDestroy() {
        this.conexion.close()
        super.onDestroy()
    }
}