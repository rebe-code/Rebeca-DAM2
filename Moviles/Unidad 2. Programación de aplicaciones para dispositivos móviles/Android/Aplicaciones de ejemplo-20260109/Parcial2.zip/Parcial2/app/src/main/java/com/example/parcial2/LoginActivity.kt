package com.example.parcial2

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.parcial2.bbdd.BBDD_Helper

class LoginActivity : AppCompatActivity() {
    val conexion = BBDD_Helper(this,"parcial2", null, 1)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.login)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        inicializarUsuarios()

        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            comprobarLogin()
        }
    }

    private fun inicializarUsuarios(){
        val bd = this.conexion.writableDatabase
        val registro = ContentValues()
        registro.put("usuario", "admin")
        registro.put("password", "admin")
        bd.insert("usuario", null, registro)
        registro.put("usuario", "invitado")
        registro.put("password", "guess")
        bd.insert("usuario", null, registro)
        registro.put("usuario", "patriciasfo")
        registro.put("password", "test")
        bd.insert("usuario", null, registro)
        this.conexion.close()
    }

    private fun comprobarLogin(){
        val usuario = findViewById<EditText>(R.id.etUsername).text
        val passw = findViewById<EditText>(R.id.etPassword).text
        if (usuario.isNullOrEmpty() || passw.isNullOrEmpty() || usuario.toString().isEmpty() || passw.toString().isEmpty()){
            Log.d("LoginActivity onCreate", "El usuario y/o la contraseña están vacíos")
            Toast.makeText(this, R.string.error_login, Toast.LENGTH_SHORT).show()
        } else{
            val bd = this.conexion.readableDatabase
            Log.d("LoginActivity onCreate", "Comprobamos datos en BBDD")
            val usu = usuario.toString()
            val clave = passw.toString()
            val fila = bd.rawQuery("SELECT * FROM usuario WHERE usuario = '$usu' and password = '$clave'", null)
            if (fila.count == 0){
                AlertDialog.Builder(this)
                    .setTitle(R.string.error)
                    .setMessage(getString(R.string.error_credenciales, usu, clave))
                    .create()
                    .show()
            } else {
                val intent = Intent(this, MontaniasActivity::class.java)
                intent.putExtra("usuario", usu)
                startActivity(intent)
            }
        }
    }

    override fun onDestroy() {
        this.conexion.close()
        super.onDestroy()
    }
}