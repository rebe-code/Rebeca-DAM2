package com.example.parcial2

class Montania (val nombre: String, val usuario: String, val altura: Int, val concejo: String)