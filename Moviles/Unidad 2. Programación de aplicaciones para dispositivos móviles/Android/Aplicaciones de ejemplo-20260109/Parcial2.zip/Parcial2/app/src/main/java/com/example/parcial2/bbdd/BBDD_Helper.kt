package com.example.parcial2.bbdd

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabase.CursorFactory
import android.database.sqlite.SQLiteOpenHelper

class BBDD_Helper(context: Context, name: String, factory: CursorFactory?, version: Int): SQLiteOpenHelper(context, name, factory, version) {
    private val SQL_CREATE_USUARIOS = "CREATE TABLE usuario(usuario VARCHAR(50) PRIMARY KEY NOT NULL, password VARCHAR(50))"
    private val SQL_DELETE_USUARIOS = "DROP TABLE IF EXISTS usuario"

    private val SQL_CREATE_MONTANIAS = "CREATE TABLE montania(nombre VARCHAR(50) NOT NULL, usuario VARCHAR(50) NOT NULL, altura INT, concejo VARCHAR(50), PRIMARY KEY (nombre, usuario))"
    private val SQL_DELETE_MONTANIAS = "DROP TABLE IF EXISTS montania"


    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(SQL_CREATE_USUARIOS)
        db.execSQL(SQL_CREATE_MONTANIAS)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL(SQL_DELETE_USUARIOS)
        db.execSQL(SQL_DELETE_MONTANIAS)
        this.onCreate(db)
    }
}