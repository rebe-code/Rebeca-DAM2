package com.example.parcial2

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CalculadoraActivity : AppCompatActivity() {
    lateinit var display: TextView
    private var numeroAnterior: String = ""
    private var numeroActual: String = ""
    private var operacion: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.calculadora)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.calculadora)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        this.display = findViewById<TextView>(R.id.display)

        val botones = arrayOf<Int>(
            R.id.ceroButton, R.id.oneButton, R.id.twoButton, R.id.threeButton, R.id.fourButton,
            R.id.fiveButton, R.id.sixButton, R.id.sevenButton, R.id.eigthButton, R.id.nineButton
        )

        for (id in botones) {
            findViewById<Button>(id).setOnClickListener {
                this.aniadirNumero((it as Button).text.toString())
            }
        }

        findViewById<Button>(R.id.plusButton).setOnClickListener { this.actualizarOperation("+") }
        findViewById<Button>(R.id.minusButton).setOnClickListener { this.actualizarOperation("-") }
        findViewById<Button>(R.id.multiButton).setOnClickListener { this.actualizarOperation("*") }
        findViewById<Button>(R.id.divButton).setOnClickListener { this.actualizarOperation("/") }

        findViewById<Button>(R.id.deleteButton).setOnClickListener { this.limpiar() }
        findViewById<Button>(R.id.equalButton).setOnClickListener { this.calcular() }
        findViewById<Button>(R.id.invButton).setOnClickListener { this.invertirNumero() }

    }

    private fun aniadirNumero(numero: String){
        this.numeroActual += numero
        this.display.text = this.numeroActual
    }

    private fun actualizarOperation(operacion: String){
        this.numeroAnterior = this.numeroActual
        this.numeroActual = getString(R.string.vacio)
        this.operacion = operacion
    }

    private fun calcular(){
        if (this.numeroAnterior.isNotEmpty() && this.numeroActual.isNotEmpty()) {
            val result = when (this.operacion) {
                "+" -> this.numeroAnterior.toInt() + this.numeroActual.toInt()
                "-" -> this.numeroAnterior.toInt() - this.numeroActual.toInt()
                "*" -> this.numeroAnterior.toInt() * this.numeroActual.toInt()
                "/" -> {
                    if (this.numeroActual != (getString(R.string.cero))){
                        this.numeroAnterior.toInt() / this.numeroActual.toInt()
                    } else {
                        Toast.makeText(this, R.string.error_division_cero, Toast.LENGTH_SHORT).show()
                        this.numeroAnterior
                    }
                }
                else -> 0
            }
            this.display.text = String.format("%s", result)
            this.numeroActual = result.toString()
            this.numeroAnterior = getString(R.string.vacio)
            this.operacion = getString(R.string.vacio)
        }
    }

    private fun limpiar(){
        this.numeroActual = getString(R.string.vacio)
        this.numeroAnterior = getString(R.string.vacio)
        this.operacion = getString(R.string.vacio)
        this.display.text = getString(R.string.cero)
    }

    private fun invertirNumero(){
        if (this.numeroActual.isNotEmpty()) {
            this.numeroActual = this.numeroActual.reversed()
            this.display.text = this.numeroActual
        }

    }

}