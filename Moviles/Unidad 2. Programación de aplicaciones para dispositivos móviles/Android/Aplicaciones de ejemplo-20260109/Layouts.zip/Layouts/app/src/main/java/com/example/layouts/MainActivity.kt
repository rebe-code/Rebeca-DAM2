package com.example.layouts

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.bbdd.BBDDHelper

class MainActivity : AppCompatActivity() {
    private val conexion = BBDDHelper(this,"layouts", null, 1)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.linear_layout_login)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_login)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        this.inicializarUsuarios()
        findViewById<Button>(R.id.boton_iniciar_sesion).setOnClickListener {
            this.iniciarSesion()
        }

        val tv = findViewById<TextView>(R.id.texto_olvidaste_contrasena)
        tv.setOnClickListener {
            val correo = findViewById<EditText>(R.id.input_usuario)
            if (correo != null && correo.text.toString() != "") {
                dialogoPersonalizado(correo.text.toString())
                /*val intent = Intent(this, RecuperarPassword::class.java)
                intent.putExtra("email", correo.text.toString())
                startActivity(intent)*/
            } else {
                Toast.makeText(this, "El correo no puede estar vacío", Toast.LENGTH_SHORT).show()
            }
        }

        /*val boton = findViewById<Button>(R.id.boton_saltar)
        boton.setOnClickListener{
            val intent = Intent(this, ColorsActivity::class.java)
            startActivity(intent)
        }*/
    }

    private fun inicializarUsuarios(){
        val bd = this.conexion.writableDatabase
        val registro = ContentValues()
        registro.put("id", 1)
        registro.put("email", "patriciasfo@educastur.org")
        registro.put("password", "patriciasfo")
        bd.insert("usuario", null, registro)
        registro.put("id", 2)
        registro.put("email", "admin@educastur.org")
        registro.put("password", "admin")
        bd.insert("usuario", null, registro)
        Log.d("MainActivity - inicializarUsuarios", "Se cargaron los usuarios en BBDD")
        bd.close()
    }

    private fun iniciarSesion(){
        val correo = findViewById<EditText>(R.id.input_usuario).text
        val passw = findViewById<EditText>(R.id.input_contrasena).text
        if (correo.isNullOrEmpty() || passw.isNullOrEmpty() || correo.toString().isEmpty() || passw.toString().isEmpty()){
            Log.d("MainActivity - iniciarSesion", "El correo y/o la contraseña están vacíos")
            Toast.makeText(this, R.string.error_login, Toast.LENGTH_SHORT).show()
        } else{
            val numUsuarios = this.consultarUsuario(correo.toString(), passw.toString())
            if (numUsuarios == 0) {
                AlertDialog.Builder(this)
                    .setTitle(R.string.error)
                    .setMessage(getString(R.string.error_credenciales, correo.toString(), passw.toString()))
                    .create()
                    .show()
            } else {
                val intent = Intent(this, ResumenLayoutActivity::class.java)
                intent.putExtra("email", correo.toString())
                intent.putExtra("password", passw.toString())
                startActivity(intent)
            }
        }
    }

    private fun consultarUsuario(correo: String, passw: String): Int{
        val bd = this.conexion.readableDatabase
        Log.d("MainActivity - consultarUsuario", "Comprobamos usuario en BBDD")
        val fila = bd.rawQuery("select id from usuario where email = '$correo' and password = '$passw'", null)
        val numeroUsuarios = fila.count
        fila.close()
        bd.close()
        return numeroUsuarios
        // ---- Si se desea recorrer el cursor con los registros consultados ----
        /*
        Log.d("MainActivity - consultarUsuario", "Ids encontrados: ")
        var id = -1
        while (fila.moveToNext()){
            id = fila.getInt(fila.getColumnIndexOrThrow("id"))
            Log.d("MainActivity - consultarUsuario", id.toString())
        }*/
        //
        /* --- Si se desea obtener sólo la información del primer registro
        if (fila.moveToFirst()){
            id = fila.getInt(0)
        }*/
    }

    private fun dialogoPersonalizado(correo: String){
        val vista = this.layoutInflater.inflate(R.layout.activity_recuperar_password, null)
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder.setView(vista)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    override fun onDestroy() {
        this.conexion.close()
        super.onDestroy()
    }

/*
        val botonEditar = findViewById<ImageButton>(R.id.boton_editar)
        botonEditar.setOnClickListener {
            val intent = Intent(this, relative_layout::class.java)
            startActivity(intent)
        }*/
    //}

    private fun crearContacto(ctx: AppCompatActivity){
        //val boton = findViewById<Button>(R.id.boton_crear_contacto)
        //boton.setOnClickListener {
            /*val intent = Intent(this, ColorsActivity::class.java)
            startActivity(intent)*/

            // Para añadir menú emergente al botón 'Añadir contacto'
            /*val popup = PopupMenu(this, boton)
            val inflater: MenuInflater = popup.menuInflater
            inflater.inflate(R.menu.boton_new_contact, popup.menu)
            popup.setOnMenuItemClickListener(
                fun (menuItem: MenuItem): Boolean {
                    Toast.makeText(ctx,"Opción '" + menuItem.getTitle() + "'", Toast.LENGTH_SHORT).show()
                    return true
                }
            )
            popup.show()*/
        //}
        // Para añadir menú contextual
        //registerForContextMenu(boton);
    }

/*
    // Crear menú de opciones
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        super.onCreateOptionsMenu(menu)
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.agenda, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection.
        return when (item.itemId) {
            R.id.nuevo_contacto -> {
                //iniciarSesion(this, BBDD_Helper(this,"contactos", null, 1))
                Toast.makeText(this, "Opción 'Nuevo contacto'", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.borrar_contacto -> {
                Toast.makeText(this, "Opción 'Borrar contacto'", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    // Menú contextual
    override fun onCreateContextMenu(menu: ContextMenu, v: View,
                                     menuInfo: ContextMenu.ContextMenuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo)
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.boton_new_contact, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        return when (item.itemId) {
            R.id.nuevo -> {
                //editNote(info.id)
                Toast.makeText(this, "Menú contextual 'Nuevo'", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.editar -> {
                Toast.makeText(this, "Menú contextual 'Editar'", Toast.LENGTH_SHORT).show()
                //deleteNote(info.id)
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }*/
}




