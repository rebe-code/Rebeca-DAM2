package com.example.layouts

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class multimedia : AppCompatActivity() {
    // Con lateinit le decimos que inicializamos la variables más tarde
    private lateinit var sp: SoundPool
    private var spLoaded: Boolean = false

    private lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.audio_multimedia)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.videoView)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val soundId = reproducirAudioCorto()
        val boton_audio_corto = findViewById<Button>(R.id.playSp)
        boton_audio_corto.setOnClickListener {
            // 3. Reproducción del sonido
            if (this.spLoaded) {
                this.sp.play(soundId, 1f, 1f, 0, 0, 1f)
            }
        }

        // 1. Inicializar el MediaPlayer con un archivo de audio de los recursos
        this.mediaPlayer = MediaPlayer.create(this, R.raw.duhast)

        //5. Configurar un listener para liberar recursos cuando la reproducción termine
        this.mediaPlayer.setOnCompletionListener {
            this.mediaPlayer.release()
        }

        // 2. Iniciar la reproducción
        val boton_play = findViewById<Button>(R.id.playMp)
        boton_play.setOnClickListener {
            this.mediaPlayer.start();
        }

        // 3. Pausar la reproducción
        val boton_pause = findViewById<Button>(R.id.pauseMp)
        boton_pause.setOnClickListener {
            if (this.mediaPlayer.isPlaying) {
                this.mediaPlayer.pause()
            }
        }

        // 4. Detener la reproducción, prepararla e inicializarla
        val boton_stop = findViewById<Button>(R.id.stopMp)
        boton_stop.setOnClickListener {
            if (this.mediaPlayer.isPlaying) {
                this.mediaPlayer.stop()
                this.mediaPlayer.prepare()
                this.mediaPlayer.seekTo(0) // Para ir a un punto concreto del audio
                // Si se liberan los recursos, al hacer play otra vez -> no funcion
                //this.mediaPlayer.release()
            }
        }
    }

    private fun reproducirAudioCorto(): Int{
        // 1. Configuración del SoundPool
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        this.sp = SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(audioAttributes)
            .build()
        // --- Fin Configuración ---

        // 2. Cargar el sonido
        val soundId = this.sp.load(this, R.raw.aplauso, 1)
        sp.setOnLoadCompleteListener { _, _, status ->
            if (status == 0) {
                this.spLoaded = true
            } else {
                Toast.makeText(this, "Carga fallida!", Toast.LENGTH_SHORT).show()
            }
        }
        // --- Fin Carga ---
        return soundId
    }

    // 4. Liberación de recursos
    override fun onDestroy() {
        super.onDestroy()
        this.sp.release()
        // Asegurarse de liberar el MediaPlayer si la actividad se destruye
        if (::mediaPlayer.isInitialized) {
            this.mediaPlayer.release()
        }
    }
}