package com.example.layouts

import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle

class ActividadDialogo : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.setContentView(R.layout.disenio_dialogo)
    }
}