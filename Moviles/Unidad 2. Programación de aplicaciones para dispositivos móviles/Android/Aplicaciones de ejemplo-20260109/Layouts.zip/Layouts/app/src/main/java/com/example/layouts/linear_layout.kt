package com.example.layouts

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class linear_layout : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.linear_layout_login)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.videoView)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        comprobarLogin()
    }

    private fun comprobarLogin() {
        val boton = findViewById<Button>(R.id.boton_iniciar_sesion)
        boton.setOnClickListener {
            val email = findViewById<EditText>(R.id.input_usuario).text.toString()
            val password = findViewById<EditText>(R.id.input_contrasena).text.toString()
            Log.println(Log.DEBUG, "MainActivity - comprobarLogin", getString(R.string.log_login, email, password))
            if (email == "patriciasfo@educastur.org" && password == "presencial") {
                val intent = Intent(this, ResumenLayoutActivity::class.java)
                intent.putExtra("email", email)
                intent.putExtra("password", password)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Login incorrecto", Toast.LENGTH_SHORT).show()
            }
        }

        val tv = findViewById<TextView>(R.id.texto_olvidaste_contrasena)
        tv.setOnClickListener {
            val correo = findViewById<EditText>(R.id.input_usuario)
            if (correo != null && correo.text.toString() != "") {
                val intent = Intent(this, RecuperarPassword::class.java)
                intent.putExtra("email", correo.text.toString())
                startActivity(intent)
            } else {
                Toast.makeText(this, "El correo no puede estar vacío", Toast.LENGTH_SHORT).show()
            }
        }
    }
}