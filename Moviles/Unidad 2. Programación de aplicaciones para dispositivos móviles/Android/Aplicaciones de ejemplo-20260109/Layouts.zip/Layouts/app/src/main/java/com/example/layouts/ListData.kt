package com.example.layouts

class ListData(val nombre: String, val concejo: String, val imagen: Int)