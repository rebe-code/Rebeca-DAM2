package com.example.layouts

import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.DialogFragment
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ResumenLayoutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.resumen_layout)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.videoView)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val correo = intent.extras?.getString("email").toString()
        val passw = intent.extras?.getString("password").toString()
        findViewById<TextView>(R.id.texto_email).text = getString(R.string.correo, correo)
        findViewById<TextView>(R.id.texto_password).text = getString(R.string.contrasenia, passw)

        // Menú contextual flotante
        val imagen = findViewById<ImageView>(R.id.imagen_layouts)
        registerForContextMenu(imagen);

        val boton_frame_layout = findViewById<Button>(R.id.boton_frame_layout)
        boton_frame_layout.setOnClickListener {
            // --- Inicio Menú Emergente en el botón FrameLayout
            val popup = PopupMenu(this, boton_frame_layout)
            val inflater: MenuInflater = popup.menuInflater
            inflater.inflate(R.menu.menu_frame_layout, popup.menu)
            popup.setOnMenuItemClickListener(
                fun (menuItem: MenuItem): Boolean {
                    return when (menuItem.itemId) {
                        R.id.frame_principal -> {
                            val intent = Intent(this, FrameActivity::class.java)
                            startActivity(intent)
                            true
                        }
                        R.id.frame_colores -> {
                            val intent = Intent(this, ColorsActivity::class.java)
                            // Para mostrar una actividad como diálogo
                            //val intent = Intent(this, ActividadDialogo::class.java)
                            startActivity(intent)
                            true
                        }
                        else -> false
                    }
                }
            )
            popup.show()
            //------------- FIN ---------------
        }

        findViewById<Button>(R.id.boton_linear_layout).setOnClickListener {
            val intent = Intent(this, linear_layout_anidados::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.boton_table_layout).setOnClickListener {
            val intent = Intent(this, table_layout::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.boton_relative_layout).setOnClickListener {
            val intent = Intent(this, relative_layout::class.java)
            startActivity(intent)
        }

        findViewById<ImageButton>(R.id.boton_volver).setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        findViewById<FloatingActionButton>(R.id.floatingActionButton).setOnClickListener {
            //sale de la app completamente; y no simplemente cierra la actividad actual.
            finishAffinity() // -> para versión igual o superior que la API 16 o Android 4.1
            //finishAndRemoveTask() // -> con Android 5 y sólo elimina la tarea de la lista de apps recientes
        }
    }

    // --- Inicio Menú Contextual Flotante
    override fun onCreateContextMenu(menu: ContextMenu, v: View,
                                     menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_imagen_layouts, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.cambiar_imagen -> {
                val imagen = findViewById<ImageView>(R.id.imagen_layouts)
                if (imagen.tag == getString(R.string.tag_imagen)){
                    imagen.setImageResource(R.drawable.puzle)
                    imagen.tag = getString(R.string.puzle)
                } else {
                    imagen.setImageResource(R.drawable.layouts)
                    imagen.tag = getString(R.string.tag_imagen)
                }
                true
            }
            R.id.acercaDe -> {
                dialogoConBotonOK()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }
    //------------- FIN ---------------

    // --- Inicio Menú de Opciones
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        super.onCreateOptionsMenu(menu)
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.layouts, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.frame -> {
                val intent = Intent(this, ColorsActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.linear -> {
                val intent = Intent(this, linear_layout_anidados::class.java)
                startActivity(intent)
                true
            }
            R.id.table -> {
                val intent = Intent(this, table_layout::class.java)
                startActivity(intent)
                true
            }
            R.id.relative -> {
                val intent = Intent(this, relative_layout::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    //------------- FIN ---------------

    private fun dialogoConBotonOK(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder
            .setMessage(R.string.mensaje_acerca_de)
            .setTitle(R.string.acerca_de)
            .setPositiveButton(R.string.ok){ _, _ -> }
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    // --- Diálogo simple, sin botones, sólo se muestra la info en una ventana
    /*private fun dialogoSimple(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder
            .setMessage("Esto es el mensaje")
            .setTitle("Esto es el título")
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }*/
    //------------- FIN ---------------

    // --- Diálogo simple con los botones de Aceptar y Cancelar
    /*private fun dialogoSimpleConBotones(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder
            .setMessage("Esto es el mensaje")
            .setTitle("Esto es el título")
            // Si no se quiere realizar ninguna tarea al pulsar los botones no hay que hacer nada.
            // El sistema cierra el diálogo automáticamente al pulsar los botones o fuera del diálogo.
            .setPositiveButton("Aceptar"){ dialog, which -> }
            .setNegativeButton("Cancelar"){ dialog, which -> }
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }*/
    //------------- FIN ---------------

    // --- Diálogo simple con lista de opción única
    /*private fun dialogoConListaOpcionUnica(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder
            //.setMessage("Esto es el mensaje") -> si se muestra el mensaje no aparece la lista
            .setTitle("Esto es el título")
            // Si no se quiere realizar ninguna tarea al pulsar los botones no hay que hacer nada.
            // El sistema cierra el diálogo automáticamente al pulsar los botones o fuera del diálogo.
            .setPositiveButton("Aceptar"){ dialog, which -> }
            .setNegativeButton("Cancelar"){ dialog, which -> }
            .setItems(arrayOf("Item 1", "Item 2", "Item 3")){ dialog, which -> }
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }*/
    //------------- FIN ---------------

    // --- Diálogo simple con lista persistente de opción múltiple
    /*private fun dialogoConListaPersistenteOpcionMultiple(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder
            .setTitle("Esto es el título")
            // Si no se quiere realizar ninguna tarea al pulsar los botones no hay que hacer nada.
            // El sistema cierra el diálogo automáticamente al pulsar los botones o fuera del diálogo.
            .setPositiveButton("Aceptar"){ dialog, which -> }
            .setNegativeButton("Cancelar"){ dialog, which -> }
            .setMultiChoiceItems(arrayOf("Item 1", "Item 2", "Item 3"), null){ dialog, which, isChecked -> }
            // Para mostrar el diálogo con alguna casilla preseleccionada
            //.setMultiChoiceItems(arrayOf("Item 1", "Item 2", "Item 3"), booleanArrayOf(false, true, true)){ dialog, which, isChecked -> }
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }*/
    //------------- FIN ---------------

    // --- Diálogo simple con lista persistente de opción única
   /* private fun dialogoConListaPersistenteOpcionUnica(){
        val builder: AlertDialog.Builder = AlertDialog.Builder(this)
        builder
            .setTitle("Esto es el título")
            // Si no se quiere realizar ninguna tarea al pulsar los botones no hay que hacer nada.
            // El sistema cierra el diálogo automáticamente al pulsar los botones o fuera del diálogo.
            .setPositiveButton("Aceptar"){ dialog, which -> }
            .setNegativeButton("Cancelar"){ dialog, which -> }
            .setSingleChoiceItems(arrayOf("Item 1", "Item 2", "Item 3"), 0){ dialog, which -> }
            // Para mostrar el diálogo con el tercer ítem preseleccionado
            //.setSingleChoiceItems(arrayOf("Item 1", "Item 2", "Item 3"), 2){ dialog, which -> }
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }*/
    //------------- FIN ---------------

    // --- Diálogo con diseño personalizado
    /*class DialogoPersonalizadoFragment: DialogFragment() {
        override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
            return activity?.let {
                val builder = AlertDialog.Builder(it)
                val inflater = requireActivity().layoutInflater
                builder.setView(inflater.inflate(R.layout.disenio_dialogo, null))
                    .setPositiveButton("Aceptar"){ dialog, id ->
                    }
                    .setNegativeButton("Cancelar", DialogInterface.OnClickListener { dialog, id ->
                    })
                builder.create()
            } ?: throw IllegalStateException("La actividad no puede ser null")
        }
    }

    private fun dialogoPersonalizado(){
        DialogoPersonalizadoFragment().show(supportFragmentManager, "Diálogo Personalizado")
    }*/
    //------------- FIN ---------------
}