package com.example.bbdd

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabase.CursorFactory
import android.database.sqlite.SQLiteOpenHelper

class BBDDHelper(context: Context, name: String, factory: CursorFactory?, version: Int): SQLiteOpenHelper(context, name, factory, version) {
    private val sqlCreateEntries = "CREATE TABLE usuario(id INT PRIMARY KEY, email VARCHAR(50), password VARCHAR(50))"
    private val sqlDeleteEntries = "DROP TABLE IF EXISTS usuario"

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(this.sqlCreateEntries)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL(this.sqlDeleteEntries)
        this.onCreate(db)
    }
}