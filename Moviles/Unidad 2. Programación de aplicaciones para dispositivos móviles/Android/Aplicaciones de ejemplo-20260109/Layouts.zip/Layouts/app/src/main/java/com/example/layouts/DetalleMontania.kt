package com.example.layouts

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DetalleMontania : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.detalle_montania)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.videoView)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<TextView>(R.id.titulo).text = intent.getStringExtra("nombre")
        findViewById<TextView>(R.id.subtítulo).text = intent.getStringExtra("concejo")
        findViewById<ImageView>(R.id.imagen).setImageResource(intent.getIntExtra("imagen", android.R.drawable.ic_menu_mapmode))
        val telefono = findViewById<TextView>(R.id.descripcion)
        telefono.text = "600231069"
        telefono.setOnClickListener {
            //val intent = Intent(Intent.ACTION_CALL)
            startActivity(Intent(Intent.ACTION_DIAL).setData(Uri.parse("tel:" + telefono.text)))
        }
    }
}