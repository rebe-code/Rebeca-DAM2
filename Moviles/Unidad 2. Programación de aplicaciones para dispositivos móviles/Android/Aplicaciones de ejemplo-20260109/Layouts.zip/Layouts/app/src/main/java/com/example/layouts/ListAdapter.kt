package com.example.layouts

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class ListAdapter(): BaseAdapter(){
    private var context: Context? = null
    private var datos: ArrayList<ListData> = ArrayList<ListData>()

    constructor(context: Context, datos: ArrayList<ListData>) : this() {
        this.context = context
        this.datos = datos
    }

    override fun getCount(): Int {
        return datos.size
    }

    override fun getItem(position: Int): Any {
        return datos[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {
        val vista = view?.let {
            view
        } ?:run{
           LayoutInflater.from(context).inflate(R.layout.item_view, parent, false)
        }

        val icono = vista.findViewById<ImageView>(R.id.miniatura)
        val nombre_mountain = vista.findViewById<TextView>(R.id.nombre)
        val concejo_mountain = vista.findViewById<TextView>(R.id.concejo)

        val datosItem = getItem(position) as ListData
        //icono.setImageResource(datosItem.imagen) -> si se comenta, el mismo icono para todas las montañas.
        //                                            Si no, cada montaña tiene su propio icono.
        nombre_mountain.text = datosItem.nombre
        concejo_mountain.setText(datosItem.concejo)

        return vista;
    }
}