package com.example.layouts

import android.annotation.SuppressLint
import android.content.ContentValues
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.bbdd.BBDDHelper
import java.util.Properties
import javax.mail.Authenticator
import javax.mail.Message
import javax.mail.MessagingException
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage


class RecuperarPassword : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_recuperar_password)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.videoView)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val conexion = BBDDHelper(this,"contactos", null, 1)
        val correo = intent.extras?.getString("email").toString()
        val boton = findViewById<Button>(R.id.boton_actualizar)
        boton.setOnClickListener {
            val bd = conexion.writableDatabase
            val registro = ContentValues()
            registro.put("password", findViewById<EditText>(R.id.et_nueva_password).text.toString())
            val cant = bd.update("login", registro, "email='$correo'", null)
            bd.close()
            //if (cant == 1) {
                Toast.makeText(this, "Se modificó la contraseña", Toast.LENGTH_SHORT).show()
                enviarCorreo()
                //onBackPressedDispatcher.onBackPressed()
            /*} else {
                Toast.makeText(this, "No se pudo modificar la contraseña", Toast.LENGTH_SHORT)
                    .show()
            }*/
        }
    }

    val smtpHost = "smtp.gmail.com"
    val smtpPort = "25" // Puerto SMTP por defecto

    private fun enviarCorreo(){
        val senderEmail = "patrisf@gmail.com"
        val recipientEmail = "patrisf@gmail.com"
        val subject = "Asunto del correo"
        val messageBody = "Cuerpo del mensaje"

        // Crear una sesión de correo
        val session = this.createSesion()
        //val session = Session.getDefaultInstance(props)
        try {
            // Crear un mensaje
            val message = MimeMessage(session)
            message.setFrom(InternetAddress(senderEmail, "otro texto"))
            message.addRecipient(Message.RecipientType.TO, InternetAddress(recipientEmail, recipientEmail))
            message.subject = subject
            message.setText(messageBody)

            // Enviar el mensaje
            /*val transport = session.getTransport("smtp")
            transport.connect(smtpHost, senderEmail, "PAT08111980")
            transport.sendMessage(message, message.allRecipients)
            transport.close()*/
            Transport.send(message)

            println("Correo enviado con éxito.")
        } catch (e: MessagingException) {
            e.printStackTrace()
            println("Error al enviar el correo: " + e.message)
        }
    }

    private fun createSesion(): Session{
        val props = Properties()
        props["mail.smtp.auth"] = "true"
        props["mail.smtp.starttls.enable"] = "true"
        props["mail.smtp.host"] = smtpHost
        props["mail.smtp.port"] = smtpPort

        return Session.getInstance(props, object: Authenticator() {
            override fun getPasswordAuthentication(): PasswordAuthentication {
                return PasswordAuthentication("patrisf@gmail.com", "")
            }
        })
    }
}