package com.example.layouts

import android.content.Intent
import android.os.Bundle
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ListViewActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.list_view)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val datos = this.obtenerDatos()
        val lista = findViewById<ListView>(R.id.list_view_montain)
        val adaptador = ListAdapter(this, datos)
        lista.adapter = adaptador

        lista.setOnItemClickListener { parent, view, position, id ->
            val montania = adaptador.getItem(position) as ListData
            val intent = Intent(this, DetalleMontania::class.java)
            intent.putExtra("nombre", montania.nombre)
            intent.putExtra("concejo", montania.concejo)
            intent.putExtra("imagen", montania.imagen)
            startActivity(intent)
        }
    }

    private fun obtenerDatos() : ArrayList<ListData>{
        val datos = arrayListOf<ListData>()
        datos.add(ListData("Los Albos", "Somiedo", R.drawable.albos))
        datos.add(ListData("Pico Caldoveiro", "Teverga",R.drawable.caldoveiro))
        datos.add(ListData("Pico Carriá", "Ponga", R.drawable.carria))
        datos.add(ListData("Peña Castil", "Cabrales", R.drawable.castil))
        datos.add(ListData("La Cruz de Priena", "Cangas de Onís", R.drawable.cruzpriena))
        datos.add(ListData("El Cueto Arbás", "Cangas del Narcea", R.drawable.cuetuarbas))
        datos.add(ListData("Pico Ferreirúa", "Teverga", R.drawable.ferreirua))
        datos.add(ListData("Pico Gorrión", "Quirós", R.drawable.gorrion))
        datos.add(ListData("Pico Jultayu", "Cangas de Onís", R.drawable.jultayu))
        datos.add(ListData("La Mesa", "Lena", R.drawable.lamesa))
        datos.add(ListData("El Monsacro", "Morcín", R.drawable.monsacro))
        datos.add(ListData("El Retriñón", "Aller", R.drawable.retrinon))
        datos.add(ListData("Pico El Siete", "Lena", R.drawable.siete))
        datos.add(ListData("Peña Ubiña", "Lena", R.drawable.ubina))
        return datos;
    }
}