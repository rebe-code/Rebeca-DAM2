package com.example.layouts

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class viedo_multimedia : AppCompatActivity() {
    private var iniciar = true
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.viedo_multimedia)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.videoView)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val vv = findViewById<VideoView>(R.id.videoView)
        //vv.setVideoPath("android.resource://" + packageName + "/" + R.raw.videoplayback)
        /*vv.setVideoURI(Uri.parse("android.resource://" + packageName + "/" + R.raw.videoplayback));
        val mediaController = MediaController(this)
        mediaController.setAnchorView(vv)
        vv.setMediaController(mediaController)*/
        //vv.requestFocus()
        val boton_play = findViewById<Button>(R.id.buttonPlay)
        boton_play.setOnClickListener {
            if (this.iniciar) {
                vv.setVideoURI(Uri.parse("android.resource://" + packageName + "/" + R.raw.videoplayback));
                val mediaController = MediaController(this)
                mediaController.setAnchorView(vv)
                vv.setMediaController(mediaController)
            }
            vv.start()
        }
        val boton_pause = findViewById<Button>(R.id.buttonPause)
        boton_pause.setOnClickListener {
            this.iniciar = false
            vv.pause()
        }
        val boton_stop = findViewById<Button>(R.id.buttonStop)
        boton_stop.setOnClickListener {
            this.iniciar = true
            vv.stopPlayback()
            vv.seekTo(0)
        }
        ;// check your path
        //val videoUri = Uri.parse("http://www.youtube.com/embed/yS_p_ICLUAw?autoplay=1&vq=small")
        // Configurar el MediaController
        // Configurar el VideoView con la URI del video
        //vv.setVideoURI(videoUri)
    }
}