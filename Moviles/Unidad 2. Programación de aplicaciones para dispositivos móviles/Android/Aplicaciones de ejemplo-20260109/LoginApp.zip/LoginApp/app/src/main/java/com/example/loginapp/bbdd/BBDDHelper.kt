package com.example.loginapp.bbdd

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabase.CursorFactory
import android.database.sqlite.SQLiteOpenHelper

class BBDDHelper(context: Context, name: String, factory: CursorFactory?, version: Int): SQLiteOpenHelper(context, name, factory, version) {
    private val sqlCreateUsuarios= "CREATE TABLE usuario(usuario VARCHAR(50) PRIMARY KEY NOT NULL, password VARCHAR(50))"
    private val sqlDeleteUsuarios = "DROP TABLE IF EXISTS usuario"

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(sqlCreateUsuarios)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL(sqlDeleteUsuarios)
        this.onCreate(db)
    }
}