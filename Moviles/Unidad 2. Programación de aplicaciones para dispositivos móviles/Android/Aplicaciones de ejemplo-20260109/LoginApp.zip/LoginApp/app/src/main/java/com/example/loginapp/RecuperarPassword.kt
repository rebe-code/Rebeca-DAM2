package com.example.loginapp

import android.content.ContentValues
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.loginapp.bbdd.BBDDHelper

class RecuperarPassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_recuperar_password)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val conexion = BBDDHelper(this, "applogin", null, 1)

        val user = intent.extras?.getString(getString(R.string.param_usuario)).toString()

        findViewById<TextView>(R.id.txt_usuario).text = getString(R.string.recover_usuario, user)

        findViewById<Button>(R.id.saveLogin).setOnClickListener {
            val newpassw = findViewById<EditText>(R.id.nueva_password).text
            val repeatpassw = findViewById<EditText>(R.id.repetir_nueva_password).text
            if (newpassw.isNullOrEmpty() || repeatpassw.isNullOrEmpty() || newpassw.toString().isEmpty()
                || repeatpassw.toString().isEmpty() || newpassw.toString() != repeatpassw.toString()){
                AlertDialog.Builder(this)
                    .setTitle(R.string.error)
                    .setMessage(getString(R.string.error_modificar_password))
                    .create()
                    .show()
            } else{
                val bd = conexion.writableDatabase
                val registro = ContentValues()
                registro.put(getString(R.string.param_password), newpassw.toString())
                val cant = bd.update("usuario", registro, "usuario='$user'", null)
                bd.close()
                if (cant == 1) {
                    Toast.makeText(this, R.string.exito_guardar_password, Toast.LENGTH_SHORT).show()
                    onBackPressedDispatcher.onBackPressed()
                } else {
                    Toast.makeText(this, R.string.error_guardar_password, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}